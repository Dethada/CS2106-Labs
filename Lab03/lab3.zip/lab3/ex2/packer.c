#include <semaphore.h>
#include <stddef.h>

#include "packer.h"

void packer_init(int balls_per_pack) {
}

void packer_destroy(void) {
}

void pack_ball(int colour, int id, int *other_ids) {
}
